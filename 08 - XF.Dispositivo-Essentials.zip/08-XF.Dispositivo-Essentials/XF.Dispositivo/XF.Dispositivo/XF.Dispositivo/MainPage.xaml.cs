﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace XF.Dispositivo
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void OnGPS_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new View.LocalizacaoView());
        }

        private void OnCompasso_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new View.CompassoView());
        }

        private void OnConectividade_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new View.ConectividadeView());
        }

        private void OnPhone_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new View.PhoneView());
        }

        private void OnShare_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new View.CompartilharView());
        }

        private void OnBateria_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new View.BateriaView());
        }
    }
}
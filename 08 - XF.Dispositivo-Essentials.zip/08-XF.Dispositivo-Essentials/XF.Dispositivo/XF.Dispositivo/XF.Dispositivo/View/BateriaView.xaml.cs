﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XF.Dispositivo.App_Code;

namespace XF.Dispositivo.View
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class BateriaView : ContentPage
	{
        public BateriaViewModel BateriaVM { get; set; }
        public object Power { get; private set; }

        public BateriaView()
        {
            BateriaVM = new BateriaViewModel();
            BindingContext = BateriaVM;

            var a = Battery.EnergySaverStatus;

            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            Battery.BatteryInfoChanged += BateriaVM.OnBatteryChanged;
            Battery.EnergySaverStatusChanged += BateriaVM.OnEnergySaverStatusChanged;
        }

        protected override void OnDisappearing()
        {
            Battery.BatteryInfoChanged -= BateriaVM.OnBatteryChanged;
            Battery.EnergySaverStatusChanged -= BateriaVM.OnEnergySaverStatusChanged;

            BateriaVM = null;

            base.OnDisappearing();
        }
    }
}
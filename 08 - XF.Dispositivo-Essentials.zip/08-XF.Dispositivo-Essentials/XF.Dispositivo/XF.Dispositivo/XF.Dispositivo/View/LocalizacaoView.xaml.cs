﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XF.Dispositivo.View
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LocalizacaoView : ContentPage
	{

        private const String Indisponivel = "Indisponível";

        private CancellationTokenSource TokenSource;

        public int PrecisaoPadrao { get; set; }

        public String[] Precicoes { get; set; }

      

        public LocalizacaoView()
        {
            InitializeComponent();

            PrecisaoPadrao = (int)GeolocationAccuracy.Low;
            Precicoes = Enum.GetNames(typeof(GeolocationAccuracy));

            PrecisaoSelecionada.ItemsSource = Precicoes;
        }


        private async void GetLocalizacaoClicked(object sender, EventArgs e)
        {
            try
            {
                Location location = await Geolocation.GetLastKnownLocationAsync();
                UltimoLocal.Text = ParseLocationToString(location);
            }
            catch (Exception ex)
            {
                UltimoLocal.Text = String.Concat("Não foi possível recuperar a localização: {0}", ex.Message);
            }
        }

        private async void GetLocalizacaoAtualClicked(object sender, EventArgs e)
        {
            try
            {
                var requisicao = new GeolocationRequest((GeolocationAccuracy) PrecisaoPadrao);
                TokenSource = new CancellationTokenSource();
                var location = await Geolocation.GetLocationAsync(requisicao, TokenSource.Token);
                AtualLocal.Text = ParseLocationToString(location);
            }
            catch (Exception ex)
            {
                AtualLocal.Text = String.Concat("Não foi possível recuperar a localização: {0}", ex.Message);
            }
            finally
            {
                TokenSource.Dispose();
                TokenSource = null;
            }
        }




        private String ParseLocationToString(Location location)
        {
            return
                $"Latitude: {location.Latitude}\n" +
                $"Longitude: {location.Longitude}\n" +
                $"Precisão: {location.Accuracy}\n" +
                $"Altitude: {(location.Altitude.HasValue ? location.Altitude.Value.ToString() : Indisponivel)}\n" +
                $"Heading: {(location.Course.HasValue ? location.Course.Value.ToString() : Indisponivel)}\n" +
                $"Velocidade: {(location.Speed.HasValue ? location.Speed.Value.ToString() : Indisponivel)}\n" +
                $"Data (UTC): {location.Timestamp:d}\n" +
                $"Horário (UTC): {location.Timestamp:T}";
        }


    }
}
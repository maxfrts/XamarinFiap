﻿using System;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XF.Dispositivo.View
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class CompartilharView : ContentPage
	{
		public CompartilharView ()
		{
			InitializeComponent ();
		}

        private async void OnTransferir_Clicked(object sender, EventArgs e)
        {
            /*
            await Share.RequestAsync(new ShareTextRequest
            {
                Subject = txtAssunto.Text,
                Text = swtTexto.IsToggled ? txtTexto.Text : null,
                Uri = swtUri.IsToggled ? txtUri.Text : null,
                Title = txtTitulo.Text
            });
            */

            await Share.RequestAsync(new ShareTextRequest
            {
                Subject = "Assunto",
                Text = "Texto",
                Uri = "www.fiap.com.br",
                Title = "Título"
            });

        }
    }
}
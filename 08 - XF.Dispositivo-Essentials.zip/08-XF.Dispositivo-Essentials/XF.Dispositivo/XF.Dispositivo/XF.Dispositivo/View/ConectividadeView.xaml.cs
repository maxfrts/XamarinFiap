﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XF.Dispositivo.View
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ConectividadeView : ContentPage
	{
        public string RedeDeAcesso { get; set; }


        public string Perfil
        {
            get
            {
                var perfis = string.Empty;

                foreach (var p in Connectivity.ConnectionProfiles)
                {
                    perfis += "\n" + p.ToString();
                }

                return perfis;
            }
        }


        public ConectividadeView()
        {
            InitializeComponent();

            RedeDeAcesso = Connectivity.NetworkAccess.ToString();

            DescricaoPerfil.Text = Perfil;
            TipoRede.Text = RedeDeAcesso;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            
            Connectivity.ConnectivityChanged += OnConectividade;
        }

        protected override void OnDisappearing()
        {
            
            Connectivity.ConnectivityChanged -= OnConectividade;
            base.OnDisappearing();
        }


        void OnConectividade(object sender, ConnectivityChangedEventArgs e)
        {
            DescricaoPerfil.Text = Perfil;
            TipoRede.Text = RedeDeAcesso;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.GoogleMaps;
using Xamarin.Forms.Xaml;

namespace XFGoogleMaps.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LocalizacaoView : ContentPage
    {

        public LocalizacaoView()
        {
            InitializeComponent();

        }

        private async void CentralizarMapaClicked(object sender, EventArgs e)
        {
            var currentLocation = await Geolocation.GetLocationAsync();
            var mapPosition = new Position(currentLocation.Latitude, currentLocation.Longitude);
            MapaGoogle.MoveToRegion(MapSpan.FromCenterAndRadius(mapPosition, Distance.FromMiles(0.2)));

        }

    }
}
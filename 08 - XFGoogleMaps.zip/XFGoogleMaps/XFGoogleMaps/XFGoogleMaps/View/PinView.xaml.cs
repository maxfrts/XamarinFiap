﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.GoogleMaps;
using Xamarin.Forms.Xaml;

namespace XFGoogleMaps.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PinView : ContentPage
    {
        public PinView()
        {
            InitializeComponent();
        }

        private async void BuscarEnderecoPressed(object sender, EventArgs e)
        {
            await LocalizarAsync(seachBarEndereco.Text);
        }

        private async Task LocalizarAsync(string endereco)
        {
            Geocoder geocoder = new Geocoder();
            Task<IEnumerable<Position>> resultado = geocoder.GetPositionsForAddressAsync(endereco);

            IEnumerable<Position> posicoes = await resultado;
            foreach (Position item in posicoes)
            {

                mapa.MoveToRegion(MapSpan.FromCenterAndRadius(item, Distance.FromMiles(0.2)));
                mapa.Pins.Add(new Pin()
                    {
                        Type = PinType.Generic,
                        Position = item,
                        Label = "Localização",
                        Address = endereco,
                    }
                );

                break;
            }
        }

        private async Task LocalizarAsync(Position position)
        {
            Geocoder geocoder = new Geocoder();
            Task<IEnumerable<string>> resultado =
                geocoder.GetAddressesForPositionAsync(position);

            IEnumerable<string> posicoes = await resultado;
            foreach (var item in posicoes)
            {
                await LocalizarAsync(item);
                break;
            }
        }
    }
}
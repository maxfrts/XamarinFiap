﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XFMasterDetail
{
    public partial class MenuPage : ContentPage
    {
        public MenuPage()
        {
            InitializeComponent();
        }

        void DashBoardClicked(object sender, System.EventArgs e)
        {
            MessagingCenter.Send<String>("", "nav-to-dashboard");
        }

        void AjusteClicked(object sender, System.EventArgs e)
        {
            MessagingCenter.Send<String>("", "nav-to-ajuste");
        }

        void MensagemClicked(object sender, System.EventArgs e)
        {
            MessagingCenter.Send<String>("", "nav-to-mensagem");
        }

    }
}

﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XFMasterDetail
{
    public partial class MensagensPage : ContentPage
    {
        public MensagensPage()
        {
            InitializeComponent();
        }
    }
}

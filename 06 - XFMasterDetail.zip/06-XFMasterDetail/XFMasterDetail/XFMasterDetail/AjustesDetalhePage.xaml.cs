﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XFMasterDetail
{
    public partial class AjustesDetalhePage : ContentPage
    {
        public AjustesDetalhePage()
        {
            InitializeComponent();
        }
    }
}

﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XFMasterDetail
{
    public partial class FramePrincipalPage : MasterDetailPage
    {
        public FramePrincipalPage()
        {
            InitializeComponent();
        }


        protected override void OnAppearing()
        {
            base.OnAppearing();

            MessagingCenter.Subscribe<String>("", "nav-to-ajuste", (sender) =>
            {
                this.Detail = new NavigationPage(new AjustePage());
                this.IsPresented = false; // Deixa ou não o menu visivel.
            });

            MessagingCenter.Subscribe<String>("", "nav-to-ajuste-detalhe", (sender) =>
            {
                this.Detail.Navigation.PushAsync(new AjustesDetalhePage());

            });

            MessagingCenter.Subscribe<String>("", "nav-to-dashboard", (sender) =>
            {
                this.Detail = new NavigationPage(new DashBoardPage() );
                this.IsPresented = true; // Deixa ou não o menu visivel.
            });


            MessagingCenter.Subscribe<String>("", "nav-to-mensagem", (sender) =>
            {
                this.Detail = new NavigationPage( new MensagensPage() );
                this.IsPresented = false; // Deixa ou não o menu visivel.
            });


        }


    }
}

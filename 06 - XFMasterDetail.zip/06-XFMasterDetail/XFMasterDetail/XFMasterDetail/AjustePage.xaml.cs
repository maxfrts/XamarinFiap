﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XFMasterDetail
{
    public partial class AjustePage : ContentPage
    {
        public AjustePage()
        {
            InitializeComponent();
        }

        void AjusteDetalheClicked(object sender, System.EventArgs e)
        {
            MessagingCenter.Send<String>("", "nav-to-ajuste-detalhe");
        }
    }
}

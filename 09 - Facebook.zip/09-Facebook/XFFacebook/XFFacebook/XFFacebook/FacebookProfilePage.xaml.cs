﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XFFacebook.Global;
using XFFacebook.ViewModel;

namespace XFFacebook
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class FacebookProfilePage : ContentPage
    {

        private string FacebookClientId = "1451390085043066";

        private FacebookProfileVM facebookProfileVM;

        public FacebookProfilePage()
        {
            InitializeComponent();

            facebookProfileVM = new FacebookProfileVM();
            this.BindingContext = facebookProfileVM;

            var facebookApiRequest =
                "https://www.facebook.com/dialog/oauth?client_id="
                + FacebookClientId
                + "&display=popup&response_type=token&redirect_uri=https://www.facebook.com/connect/login_success.html";

            var webView = new WebView
            {
                Source = facebookApiRequest,
                HeightRequest = 1
            };

            webView.Navigated += WebViewOnNavigated;

            Content = webView;

        }

        private async void WebViewOnNavigated(object sender, WebNavigatedEventArgs e)
        {
            var accessToken = GetAccessToken(e.Url);

            GlobalConfigs.FacebookToken = accessToken;

            if (accessToken != "")
            {
                await facebookProfileVM.GetFacebookUserDetailsAsync(accessToken);
                Content = MainStackLayout;
            }

        }



        private string GetAccessToken(string url)
        {
            if (url.Contains("access_token") && url.Contains("&expires_in="))
            {
                var address = url.Replace("https://www.facebook.com/connect/login_success.html#access_token=", "");
                var accessToken = address.Remove(address.IndexOf("&expires_in="));
                return accessToken;
            }

            return string.Empty;
        }

        private void Button_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new GlobalPage());
        }
    }
}
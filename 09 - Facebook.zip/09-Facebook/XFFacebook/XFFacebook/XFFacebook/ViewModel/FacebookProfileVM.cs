﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using XFFacebook.Model;
using XFFacebook.Services;

namespace XFFacebook.ViewModel
{
    public class FacebookProfileVM : INotifyPropertyChanged
    {

        private FacebookProfile facebookProfile;
        public FacebookProfile FacebookProfile
        {
            get { return facebookProfile; }
            set { facebookProfile = value; }
        }

        public async Task GetFacebookUserDetailsAsync(string accessToken)
        {
            var facebookServices = new FacebookServices();
            FacebookProfile = await facebookServices.GetFacebookProfileAsync(accessToken);
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using XFFacebook.Global;

namespace XFFacebook
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class GlobalPage : ContentPage
    {
        public GlobalPage()
        {
            InitializeComponent();
            token.Text = GlobalConfigs.FacebookToken;
        }
    }
}
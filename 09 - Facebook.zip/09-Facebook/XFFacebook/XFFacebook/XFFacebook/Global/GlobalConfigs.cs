﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XFFacebook.Global
{
    public static class GlobalConfigs
    {

        public static String FacebookToken { get; set; }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace XF.Layout
{
	public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();
		}

        private void ButtonStackLayoutClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new Views.StackLayoutPage());
        }

        private void ButtonAbsoluteLayoutClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new Views.AbsoluteLayoutPage());
        }


        private void ButtonRelativeLayoutClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new Views.RelativeLayoutPage());
        }

        private void ButtonGridLayoutClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new Views.GridLayoutPage());
        }

        private void ButtonFlexLayoutClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new Views.FlexLayoutPage());
        }


        

    }
}

﻿
namespace FiapCoin.Views.Components
{
    public interface IMessage
    {

        void LongAlert(string message);
        void ShortAlert(string message);

    }
}

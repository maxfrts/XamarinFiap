﻿using System;
namespace FiapCoin.Views.Components
{
    public class BarcodeValueBindingAttached
    {
        public BarcodeValueBindingAttached()
        {
        }
    }
}

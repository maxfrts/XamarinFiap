﻿using System;
using System.Collections.Generic;

namespace FiapCoin.Model
{
    public class Global
    {
        public static InvestidorModel Investidor { get; set; }

        public static IList<PerfilModel> Perfis { get; set; }

        public static MoedaModel MoedaPosicaoDetalhe { get; set; }
    }
}




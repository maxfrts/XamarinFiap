﻿using System;
using System.Collections.Generic;
using System.IO;
using Xamarin.Forms;
using XFSqlite.Config;
using XFSqlite.Model;

namespace XFSqlite.Repository
{
    public class InvestidorRepository: IDisposable
    {

        private SQLite.SQLiteConnection connection;

        public InvestidorRepository()
        {
            var dbConfig = DependencyService.Get<IDbPathConfig>();
            var caminho = Path.Combine(dbConfig.Path, "fiap.db");
            connection = new SQLite.SQLiteConnection(caminho);
            connection.CreateTable<InvestidorModel>();
        }


        public IList<Model.InvestidorModel> GetList()
        {
            return connection.Table<Model.InvestidorModel>().ToList();
        }

        public Model.InvestidorModel Get(int id)
        {
            return connection.Table<Model.InvestidorModel>().Where(i => i.IdUsuario == id).FirstOrDefault();
        }

        public void Insert(Model.InvestidorModel _investidorModel)
        {
            connection.Insert(_investidorModel);
        }


        public void Update(Model.InvestidorModel _investidorModel)
        {
            connection.Update(_investidorModel);
        }

        public void Delete(Model.InvestidorModel _investidorModel)
        {
            connection.Delete(_investidorModel);
        }

        public void DropTable()
        {
            connection.DropTable<Model.InvestidorModel>();
        }



        public void Dispose()
        {
            if (connection != null)
            {
                connection.Dispose(); // Liberar a conexão
            }
        }
    }
}

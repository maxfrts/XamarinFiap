﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XFSqlite.View
{
    public partial class InvestidorView : ContentPage
    {
        public InvestidorView()
        {
            InitializeComponent();
        }
    }
}

﻿using System;
namespace XFSqlite.Config
{
    public interface IDbPathConfig
    { 
        String Path { get;}
    }
}

﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Xamarin.Forms;
using XFSqlite.Model;
using XFSqlite.Repository;

namespace XFSqlite.ViewModel
{
    public class InvestidorViewModel : INotifyPropertyChanged
    {

        private InvestidorRepository repository;

        public InvestidorViewModel()
        {
            repository = new InvestidorRepository();


            // Listando todo so investidores
            Investidores = new ObservableCollection<InvestidorModel>(repository.GetList());


            GravarClickedCommand = new Command(() =>
            {
                var mensagem = "Dados do investidor alterados com sucesso!";
                try
                {
                    InvestidorModel model = new InvestidorModel()
                    {
                        NomeInvestidor = this.NomeInvestidor,
                        EmailInvestidor = this.EmailInvestidor
                    };

                    repository.Insert(model);

                    // Atualizando a lista
                    Investidores = new ObservableCollection<InvestidorModel>(repository.GetList());
                }
                catch (Exception ex)
                {
                    mensagem = "Não foi possível alterar os dados do investidor. Verifique sua conexão! \n Detalhe: " +
                        ex.Message;
                }

                Application.Current.MainPage.DisplayAlert("Investidor", mensagem, "OK");

            });


        }


        private ObservableCollection<InvestidorModel> investidores;
        public ObservableCollection<InvestidorModel> Investidores
        {
            get { return investidores; }
            set
            {
                if (investidores != value)
                {
                    investidores = value;
                    NotifyPropertyChanged();
                }
            }
        }


        private int idUsuario;
        public int IdUsuario
        {
            get { return idUsuario; }
            set
            {
                if (idUsuario != value)
                {
                    idUsuario = value;
                    NotifyPropertyChanged();
                }
            }
        }

        private String nomeInvestidor;
        public String NomeInvestidor
        {
            get { return nomeInvestidor; }
            set
            {
                if (nomeInvestidor != value)
                {
                    nomeInvestidor = value;
                    NotifyPropertyChanged();
                }
            }
        }


        private String emailInvestidor;
        public String EmailInvestidor
        {
            get { return emailInvestidor; }
            set
            {
                if (emailInvestidor != value)
                {
                    emailInvestidor = value;
                    NotifyPropertyChanged();
                }
            }
        }


        public ICommand GravarClickedCommand { get; private set; }


        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


    }
}

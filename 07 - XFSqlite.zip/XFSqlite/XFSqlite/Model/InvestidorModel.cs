﻿using System;
using SQLite;

namespace XFSqlite.Model
{
    public class InvestidorModel
    {


        private int idUsuario;

        [PrimaryKey, AutoIncrement]
        public int IdUsuario
        {
            get { return idUsuario; }
            set
            {
                if (idUsuario != value)
                {
                    idUsuario = value;
                }
            }
        }

        private String nomeInvestidor;
        public String NomeInvestidor
        {
            get { return nomeInvestidor; }
            set
            {
                if (nomeInvestidor != value)
                {
                    nomeInvestidor = value;
                }
            }
        }

        private String emailInvestidor;
        public String EmailInvestidor
        {
            get { return emailInvestidor; }
            set
            {
                if (emailInvestidor != value)
                {
                    emailInvestidor = value;
                }
            }
        }

    }
}

﻿using System;
using XFSqlite.Config;
using Xamarin.Forms;

[assembly: Dependency(typeof(XFSqlite.Droid.Config.DbPathConfig))]
namespace XFSqlite.Droid.Config
{
    public class DbPathConfig : IDbPathConfig
    {

        private String path;

        public String Path
        {
            get
            {
                if (String.IsNullOrEmpty(path))
                {
                    path = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                }
                return path;
            }
        }

    }
}

﻿using System;
using XFSqlite.Config;
using Xamarin.Forms;


[assembly: Dependency(typeof(XFSqlite.iOS.Config.DbPathConfig))]
namespace XFSqlite.iOS.Config
{
    public class DbPathConfig : IDbPathConfig
    {

        private String path;

        public String Path
        {
            get
            {
                if (String.IsNullOrEmpty(this.path))
                {
                    path = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal);
                    path = System.IO.Path.Combine(path, "..", "Library");
                }
                return path;
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XFShoppingMessage.Views
{
    public partial class ProdutoDetalhePage : ContentPage
    {
        public ProdutoDetalhePage()
        {
            InitializeComponent();
        }

        void AdicionarClicked(object sender, System.EventArgs e)
        {
            MessagingCenter.Send<String>("", "adicionarItem");
            Navigation.PopAsync();
        }
    }
}

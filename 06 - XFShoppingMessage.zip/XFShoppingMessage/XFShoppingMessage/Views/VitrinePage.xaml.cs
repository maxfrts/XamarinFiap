﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace XFShoppingMessage.Views
{
    public partial class VitrinePage : ContentPage
    {

        private int quantidade;
        private string mensagemQuantidade;

        public VitrinePage()
        {
            InitializeComponent();
            quantidade = 0;
            mensagemQuantidade = "Itens: {0}";

            MessagingCenter.Subscribe<String>("", "adicionarItem", (sender) => {
                quantidade++;
                CarrinhoItem.Text = String.Format(mensagemQuantidade, quantidade);
            });
        }

        void PressedDetalhe(object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new ProdutoDetalhePage());
        }




    }
}

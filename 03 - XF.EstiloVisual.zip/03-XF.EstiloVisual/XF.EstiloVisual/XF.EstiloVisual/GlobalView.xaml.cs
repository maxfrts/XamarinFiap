﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XF.EstiloVisual
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class GlobalView : ContentPage
	{
		public GlobalView ()
		{
			InitializeComponent ();
		}
	}
}
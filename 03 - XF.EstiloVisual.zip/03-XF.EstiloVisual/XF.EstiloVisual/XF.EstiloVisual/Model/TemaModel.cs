﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XF.EstiloVisual.Model
{
    public class TemaModel
    {
        public string HeaderFIAP
        {
            get
            {
                return "Xamarin.Forms - Cross-Platform";
            }
        }
        public string FooterFIAP
        {
            get
            {
                return "FIAP - Xamarin 2019®";
            }
        }
    }
}

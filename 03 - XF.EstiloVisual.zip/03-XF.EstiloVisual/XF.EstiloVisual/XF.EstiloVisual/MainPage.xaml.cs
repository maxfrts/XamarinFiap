﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace XF.EstiloVisual
{
	public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();
		}

        private void OnSimplesView_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new SimplesView());
        }

        private void OnGlobal_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new GlobalView());
        }

        private void OnDinamico_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new DinamicoView());
        }

        private void OnTemplate_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new TemaView());
        }

        
    }
}

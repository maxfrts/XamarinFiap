﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XF.OutBackX.Menu
{
    public class MainPageMenuItem
    {
        public string Descricao { get; set; }
        public string Icone { get; set; }
        public Type TargetType { get; set; }
    }
}

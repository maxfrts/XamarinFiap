﻿using System;
using System.Collections.Generic;
using System.Text;
using XF.OutBackX.Model;

namespace XF.OutBackX.ViewModel
{
    public class RestauranteViewModel
    {
        public RestauranteModel RestauranteModel { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.OutBackX.Models
{
    public enum NivelLotacao
    {
        VAZIO = 0,
        POUCO_CHEIO = 1,
        CHEIO = 2,
        MUITO_CHEIO = 3,
        LOTADO = 4
    }
}
